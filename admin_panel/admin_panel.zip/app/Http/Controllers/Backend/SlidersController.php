<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Model\Slider;

class SlidersController extends Controller
{
    public function slidersview(){ 	
    	$data['allData'] = Slider::all();
    	 return view('backend.slider.view-slider',$data);
    }

    public function slidersadd(){
    	 	return view('backend.slider.add-slider');
    	 }

    	 public function slidersstore(Request $request){    	 		
    	 		$data = new Slider();
    	 		$data->short_title = $request->short_title;
    	 		$data->long_title = $request->long_title;
    	 		$data->created_by = Auth::user()->id;
    	 		if ($request->file('image')){
    	 			$file = $request->file('image');
    	 			
    	 			$filename =date('YmdHi').$file->getClientOriginalName();
    	 			$file->move(public_path('upload/sliders_images'), $filename);
    	 			$data['image']= $filename;
    	 		}
    	 		$data->save();
    	 		return redirect()->route('sliders.view')->with('success', 'Data Inserted successfully'); 

    	 }

    	 public function slidersedit($id){
    	 	$editData = Slider::find($id);
    	 	return view('backend.slider.edit-slider',compact('editData'));
    	 }

    	 public function slidersupdate(Request $request, $id){
    	 		$data = Slider::find($id);
    	 		$data->short_title = $request->short_title;
    	 		$data->long_title = $request->long_title;
    	 		$data->updated_by = Auth::user()->id;
    	 		if ($request->file('image')){
    	 			$file = $request->file('image');
    	 			@unlink(public_path('upload/sliders_images/'.$data->image));
    	 			$filename =date('YmdHi').$file->getClientOriginalName();
    	 			$file->move(public_path('upload/sliders_images'), $filename);
    	 			$data['image']= $filename;
    	 		}
    	 		$data->save();
    	 		return redirect()->route('sliders.view')->with('success', 'Data updated successfully');
    	 }

    	public function slidersdelete($id){
    			$slider = Slider::find($id);
    			if (file_exists('public/upload/sliders_images/' . $slider->image) AND ! empty($slider->image)){
    				unlink('public/upload/sliders_images' . $slider->image);
    			}
    			$slider->delete();
    			return redirect()->route('sliders.view')->with('success', 'Data Deleted successfully');
    	}
}

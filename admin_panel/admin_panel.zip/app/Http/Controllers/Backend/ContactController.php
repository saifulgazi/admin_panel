<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Model\Contact;
use App\Model\Communicate;


class ContactController extends Controller
{
    public function contactview(){ 
    	$data['countMission']= Contact::count();	
    	$data['allData'] = Contact::all();
    	 return view('backend.contact.view-contact',$data);
    }

    public function contactadd(){
    	 	return view('backend.contact.add-contact');
    	 }

    	 public function contactstore(Request $request){    	 		
    	 		$data = new Contact();
    	 		$data->address = $request->address;
    	 		$data->email = $request->email;
    	 		$data->mobile = $request->mobile;
    	 		$data->facebook = $request->facebook;
    	 		$data->linkedin = $request->linkedin;
    	 		$data->youtube = $request->youtube;
    	 		$data->created_by = Auth::user()->id;
    	 		if ($request->file('image')){
    	 			$file = $request->file('image');
    	 			
    	 			$filename =date('YmdHi').$file->getClientOriginalName();
    	 			$file->move(public_path('upload/contact_images'), $filename);
    	 			$data['image']= $filename;
    	 		}
    	 		$data->save();
    	 		return redirect()->route('contact.view')->with('success', 'Data Inserted successfully'); 

    	 }

    	 public function contactedit($id){
    	 	$editData = Contact::find($id);
    	 	return view('backend.contact.edit-contact',compact('editData'));
    	 }

    	 public function contactupdate(Request $request, $id){
    	 		$data = Contact::find($id);
    	 		$data->address = $request->address;
    	 		$data->email = $request->email;
    	 		$data->mobile = $request->mobile;
    	 		$data->facebook = $request->facebook;
    	 		$data->linkedin = $request->linkedin;
    	 		$data->youtube = $request->youtube;
    	 		$data->created_by = Auth::user()->id;
    	 		if ($request->file('image')){
    	 			$file = $request->file('image');
    	 			@unlink(public_path('upload/contact_images/'.$data->image));
    	 			$filename =date('YmdHi').$file->getClientOriginalName();
    	 			$file->move(public_path('upload/contact_images'), $filename);
    	 			$data['image']= $filename;
    	 		}
    	 		$data->save();
    	 		return redirect()->route('contact.view')->with('success', 'Data updated successfully');
    	 }

    	public function contactdelete($id){
    			$contact = Contact::find($id);
    			if (file_exists('public/upload/contact_images/' . $contact->image) AND ! empty($contact->image)){
    				unlink('public/upload/contact_images' . $contact->image);
    			}
    			$contact->delete();
    			return redirect()->route('contact.view')->with('success', 'Data Deleted successfully');
    	}


        public function viewcommunicate(){
            $allData = Communicate::orderBy('id','desc')->get();
           return view('backend.contact.view-communicate',compact('allData'));
        }

        public function deletecommunicate($id){
               $communicate = Communicate::find($id);
               $communicate->delete(); 
               return redirect()->route('contact.communicate')->with('success','Data deleted successfully');
        }
}

<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Model\Cservice;

class ConserviceController extends Controller
{
    public function conserviceview(){ 	
    	$data['allData'] = Cservice::all();
    	 return view('backend.conservice.view-conservice',$data);
    }

    public function conserviceadd(){
    	 	return view('backend.conservice.add-conservice');
    	 }

    	 public function conservicestore(Request $request){    	 		
    	 		$data = new Cservice();
    	 		$data->service = $request->service;
    	 		$data->created_by = Auth::user()->id;
    	 		$data->save();
    	 		return redirect()->route('conservice.view')->with('success', 'Data Inserted successfully'); 

    	 }

    	 public function conserviceedit($id){
    	 	$editData = Cservice::find($id);
    	 	return view('backend.conservice.edit-conservice',compact('editData'));
    	 }

    	 public function conserviceupdate(Request $request, $id){
    	 		$data = Cservice::find($id);
    	 		$data->service = $request->service;
    	 		$data->created_by = Auth::user()->id;
    	 		$data->save();
    	 		return redirect()->route('conservice.view')->with('success', 'Data updated successfully');
    	 }

    	public function conservicedelete($id){
    			$conservice = Cservice::find($id);
    			$conservice->delete();
    			return redirect()->route('conservice.view')->with('success', 'Data Deleted successfully');
    	}
}

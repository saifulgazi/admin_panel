<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Model\About;

class AboutController extends Controller
{
    public function aboutview(){ 
    	$data['countMission']= About::count();	
    	$data['allData'] = About::all();
    	 return view('backend.about.view-about',$data);
    }

    public function aboutadd(){
    	 	return view('backend.about.add-about');
    	 }

    	 public function aboutstore(Request $request){    	 		
    	 		$data = new About();
    	 		$data->title = $request->title;
    	 		$data->created_by = Auth::user()->id;
    	 		$data->save();
    	 		return redirect()->route('about.view')->with('success', 'Data Inserted successfully'); 

    	 }

    	 public function aboutedit($id){
    	 	$editData = About::find($id);
    	 	return view('backend.about.edit-about',compact('editData'));
    	 }

    	 public function aboutupdate(Request $request, $id){
    	 		$data = About::find($id);
    	 		$data->title = $request->title;
    	 		$data->updated_by = Auth::user()->id;
    	 		$data->save();
    	 		return redirect()->route('about.view')->with('success', 'Data updated successfully');
    	 }

    	public function aboutdelete($id){
    			$about = About::find($id);
    			if (file_exists('public/upload/about_images/' . $about->image) AND ! empty($about->image)){
    				unlink('public/upload/about_images' . $about->image);
    			}
    			$about->delete();
    			return redirect()->route('about.view')->with('success', 'Data Deleted successfully');
    	}
}

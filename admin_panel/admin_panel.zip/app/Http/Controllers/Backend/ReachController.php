<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Model\Reach;

class ReachController extends Controller
{
    public function reachview(){ 
    	$data['countReach'] = Reach::count();	
    	$data['allData'] = Reach::all();
    	 return view('backend.reach.view-reach',$data);
    }

    public function reachadd(){
    	 	return view('backend.reach.add-reach');
    	 }

    	 public function reachstore(Request $request){    	 		
    	 		$data = new Reach();
    	 		$data->address = $request->address;
    	 		$data->email = $request->email;
    	 		$data->mobile = $request->mobile;
    	 		$data->map = $request->map;
    	 		$data->created_by = Auth::user()->id;
    	 		$data->save();
    	 		return redirect()->route('reach.view')->with('success', 'Data Inserted successfully'); 

    	 }

    	 public function reachedit($id){
    	 	$editData = Reach::find($id);
    	 	return view('backend.reach.edit-reach',compact('editData'));
    	 }

    	 public function reachupdate(Request $request, $id){
    	 		$data = Reach::find($id);
    	 		$data->address = $request->address;
    	 		$data->email = $request->email;
    	 		$data->mobile = $request->mobile;
    	 		$data->map = $request->map;   	 		
    	 		$data->created_by = Auth::user()->id;
    	 		$data->save();
    	 		return redirect()->route('reach.view')->with('success', 'Data updated successfully');
    	 }

    	public function reachdelete($id){
    			$reach= Reach::find($id);
    			$reach->delete();
    			return redirect()->route('reach.view')->with('success', 'Data Deleted successfully');
    	}
}

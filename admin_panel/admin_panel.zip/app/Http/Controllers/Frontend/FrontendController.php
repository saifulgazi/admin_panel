<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Logo;
use App\Model\Slider;
use App\Model\Contact;
use App\Model\About;
use App\Model\Communicate;
use App\Model\Reach;
use Mail;



class FrontendController extends Controller
{
    public function index(){
        $data['logo'] = Logo::first();
        $data['sliders'] = Slider::all();
        $data['contact'] = Contact::first();
    	return view('frontend.layouts.home',$data);
    }

    public function about(){
        $data['logo'] = Logo::first();
        $data['contact'] = Contact::first();
        $data['about'] = About::first();
    	return view('frontend.layouts.about',$data);
    }

    public function contact(){
        $data['logo'] = Logo::first();
        $data['contact'] = Contact::first();
        $data['contactpage'] = Reach::first();
        $data['services'] = Cservice::all();
    	return view('frontend.layouts.contact',$data);  
    }



    public function constore(Request $request){

            $con = new Communicate();
            $con->name = $request->name;
            $con->email= $request->email;
            $con->mobile_no = $request->mobile_no;
            $con->address = $request->address;
            $con->msg = $request->msg;
            $con->save();

            $data = array(
                    'name' => $request->name,
                    'email' => $request->email,
                    'mobile_no' => $request->mobile_no,
                    'address' => $request->address,
                    'msg' => $request->msg
            );

            // Mail::send('frontend.emails.contact',$data, function($message) use($data){
            //       $message->from('saifulgazi1629@gmail.com','Kaizen It Ldt.');
            //       $message->to($data['email']);
            //       $message->subject('Thanks for contact us');  
            // });


            return redirect()->back()->with('success','Your message successfully sent');
    }

}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdmissionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admissions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('student_name');
            $table->string('father_name');
            $table->string('mother_name');
            $table->string('present_add');
            $table->string('permanent_add');
            $table->string('nid');
            $table->string('occupation');
            $table->string('date');
            $table->string('nationality');
            $table->string('gender');
            $table->string('phone');
            $table->string('email');
            $table->string('guardian_phone');
            $table->string('relation_with_guardian');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admissions');
    }
}
